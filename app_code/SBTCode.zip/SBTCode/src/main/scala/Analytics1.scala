// Code for Linear Regression model

// Import required libraries

import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._ 
import org.apache.spark.rdd._
import org.apache.spark.mllib.regression.LabeledPoint
import org.apache.spark.mllib.linalg.Vectors   
import org.apache.spark.ml.feature.{VectorAssembler} 
import org.apache.spark.ml.evaluation.{RegressionEvaluator}    
import org.apache.spark.ml.regression.{LinearRegression} 
import org.apache.spark.SparkContext 
import org.apache.spark.SparkContext._ 
import org.apache.spark.sql.types._
import org.apache.spark.sql.SQLContext


object Analytic1Code {                                                                                                  
def main(args: Array[String]) {

// create spark context
val sc = new SparkContext()    

// create sql context
val sqlContext = new SQLContext(sc)

// create dataframe 
val df = sqlContext.read.format("csv").option("inferSchema","true").load("featuresCleanedForSampling")  

// Change column names
val df2 = df.withColumn("Avg_Wind",df("_c3").cast(DoubleType)).withColumn("Prec",df("_c4").cast(DoubleType)).withColumn("Snow",df("_c5").cast(DoubleType)).withColumn("Max_Temp",df("_c6").cast(IntegerType)).withColumn("Min_Temp",df("_c7").cast(IntegerType)).withColumn("Dep_delay",df("_c8").cast(DoubleType)).withColumn("Arr_delay",df("_c9").cast(DoubleType)).withColumn("Dist",df("_c10").cast(DoubleType)).drop("_c0").drop("_c1").drop("_c2").drop("_c3").drop("_c4").drop("_c5").drop("_c6").drop("_c7").drop("_c8").drop("_c9").drop("_c10") 

// Rename Dep_Delay as label
val df3 = df2.withColumnRenamed("Dep_Delay", "label")  

// Create an assembler to group features
var assembler = new VectorAssembler().setInputCols(Array("Avg_Wind","Prec","Snow","Max_Temp","Min_Temp","Arr_delay","Dist")).setOutputCol("features")      

val df4 = assembler.transform(df3)
// Split the data in train/test
var Array(train,test) = df4.randomSplit(Array(.75, .25),40)

// Get LinearRegression object
val lr = new LinearRegression()           

// Train the model
val lrModel = lr.fit(train)  

// Get predictions for test data
val lrPredictions = lrModel.transform(test)

// Evalute the model
val r2Evaluator = new RegressionEvaluator()
val res = sc.parallelize(Array(r2Evaluator.evaluate(lrPredictions)))
res.saveAsTextFile("RegRes")
print(r2Evaluator.evaluate(lrPredictions))

sc.stop()            
 }       
}

